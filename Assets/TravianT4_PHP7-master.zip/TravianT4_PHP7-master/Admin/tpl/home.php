﻿<div align="center">
	<ul class="tabs">
		<li><a id="a_title_1" onclick="SetCurrent(1);" class="current" href="#">نخست</a></li>
		<li><a id="a_title_2" onclick="SetCurrent(2);" href="#">آمار ورود</a></li>
		<li><a id="a_title_3" onclick="SetCurrent(3);" href="#">مشخصات سرور</a></li>
	</ul>
</div>
				
<div id="div_1">
	<table style="width:100%;">
		<tr>
			<td align="center"><a href="index.php?p=News"><img title="ویرایش خبرها" src="images/icon/edit-icon.png"></a></td>
			<td align="center"><img title="ويرايش مطلب" src="images/icon/floppy-icon.png"></td>
			<td align="center"><img title="مديريت نظرات" src="images/icon/fav-b-add-icon.png"></td>
			<td align="center"><img title="دسته بندي ها" src="images/icon/documents-or-copy-icon.png"></td>
		</tr>
		<tr>
			<td align="center"><a href="index.php?p=News">ویرایش خبرها</a></td>
			<td align="center">
			<a href="postmgr.php">آرشيو مطالب</a></td>
			<td align="center"><a href="comment.php">مديريت نظرات</a></td>
			<td align="center"><a href="cat.php">دسته بندي ها</a></td>
		</tr>
		<tr>
			<td align="center" style="height: 8px"></td>
			<td align="center" style="height: 8px"></td>
			<td align="center" style="height: 8px"></td>
			<td align="center" style="height: 8px"></td>
		</tr>
				<tr>
			<td align="center"><img title="مديريت لينك ها" longdesc="مديريت لينك ها" src="images/icon/web-search-icon.png"></td>
			<td align="center"><img title="بلوك ها" longdesc="بلوك ها" src="images/icon/window-b-icon.png"></td>
			<td align="center"><img title="صفحات اضافي" longdesc="صفحات اضافي" src="images/icon/documents-or-copy-icon.png"></td>
			<td align="center"><img title="مديريت اعضا" longdesc="مديريت اعضا" src="images/icon/group-of-users-icon.png"></td>
		</tr>

		<tr>
			<td align="center"><a href="simplelink.php">لينك ها</a></td>
			<td align="center"><a href="block.php">بلوك ها</a></td>
			<td align="center"><a href="extra.php">صفحات اضافي</a></td>
			<td align="center"><a href="member.php">مديريت اعضا</a></td>
		</tr>
		<tr>
			<td align="center" style="height: 8px"></td>
			<td align="center" style="height: 8px"></td>
			<td align="center" style="height: 8px"></td>
			<td align="center" style="height: 8px"></td>
		</tr>
				<tr>
			<td align="center"><img title="صندوق پيام ها" longdesc="صندوق پيام ها" src="images/icon/mail-send-icon.png"></td>
			<td align="center"><img title="مديريت فايل" longdesc="مديريت فايل" src="images/icon/folder-open-icon.png"></td>
			<td align="center"><img title="ليست سياه" longdesc="ليست سياه " src="images/icon/delete-user-icon.png"></td>
			<td align="center"><img title="خبرنامه" longdesc="خبرنامه" src="images/icon/fav-add-icon.png"></td>
		</tr>

		<tr>
			<td align="center"><a href="inbox.php">پيام ها</a></td>
			<td align="center"><a href="uc.php">مديريت فايل</a></td>
			<td align="center"><a href="banned.php">ليست سياه</a></td>
			<td align="center"><a href="newsletter.php">خبرنامه</a></td>
		</tr>
		<tr>
			<td align="center" style="height: 8px"></td>
			<td align="center" style="height: 8px"></td>
			<td align="center" style="height: 8px"></td>
			<td align="center" style="height: 8px"></td>
		</tr>
				<tr>
			<td align="center"><img title="تنظيمات" longdesc="تنظيمات" src="images/icon/window-icon.png"></td>
			<td align="center"><img title="قالب سايت" longdesc="قالب سايت" src="images/icon/paint-icon.png"></td>
			<td align="center"><img title="پشتيبان گيري" longdesc="پشتيبان گيري " src="images/icon/refresh-icon.png"></td>
			<td align="center"><img title="بروز رساني" longdesc="بروز رساني" src="images/icon/wizard-icon.png"></td>
		</tr>

		<tr>
			<td align="center"><a href="setting.php">تنظيمات</a></td>
			<td align="center"><a href="template.php">قالب سايت</a></td>
			<td align="center"><a href="backup.php">پشتيبان گيري</a></td>
			<td align="center"><a href="update.php">بروز رساني</a></td>
		</tr>
		<tr>
			<td align="center" style="height: 8px"></td>
			<td align="center" style="height: 8px"></td>
			<td align="center" style="height: 8px"></td>
			<td align="center" style="height: 8px"></td>
		</tr>

		<tr>
			<td align="center"><a href="ymsgr:sendim?westehran"><img title="پشتيباني" src="images/icon/help-icon.png"></a></td>
			<td align="center"></td>
			<td align="center"><a href="<?php echo HOMEPAGE; ?>" target="_blank"><img title="مشاهده سايت" src="images/icon/web-icon.png"></a></td>
			<td align="center"><a href="?action=logout"><img title="خروج" src="images/icon/close-icon.png"></a></td>
		</tr>

		<tr>
			<td align="center"><a href="ymsgr:sendim?trafian_ir">پشتيباني</a></td>
			<td align="center"></td>
			<td align="center"><a href="<?php echo HOMEPAGE; ?>" target="_blank">مشاهده سرور</a></td>
			<td align="center"><a href="?action=logout">خروج</a></td>
		</tr>

	</table>
</div>
<div id="div_2" style="display:none;">
    <table id="member" border="1" cellpadding="3"> 
        <tr>
            <td><b>Log ID</b></td>
            <td><b>Admin</b></td>
            <td><b>LOG</b></td> 
            <td><b>Date</b></td>
            <td><b>عملیات</b></td>
        </tr>
    <?php
    
    $sql = mysql_query("SELECT * FROM ".TB_PREFIX."admin_log ORDER BY id DESC LIMIT 10");
    $query = count($sql);
        if($query>0){
            while($row = mysql_fetch_array($sql)){
                $admid = $row['user'];
                $user = $database->getUserField($admid,"username",0);
                if($user == 'Multihunter') {
                    $admin = '<b>Control Panel</b>';
                } else {
                    $admin = '<a href="admin.php?p=player&uid='.$admid.'">'.$user.'</a>';
                }
                echo '
                <tr id="log'.$row['id'].'">
                    <td>'.$row['id'].'</td>
                    <td>'.$admin.'</td>
                    <td>'.$row['log'].'</td>
                    <td>'. date("d.m.Y H:i:s",$row['time']+3600*2).'</td>
                    <td><a onclick="dellog('.$row['id'].')" href="javascript:void(0)"><img border="0" src="../img/admin/delete.png"></a></td>
                </tr>
                ';
            }
        }
    ?>
    </table>
</div>
<div id="div_3" style="display:none;">
	<?php
    $tribe1 = mysql_query("SELECT * FROM ".TB_PREFIX."users WHERE tribe = 1 and id>3");
    $tribe2 = mysql_query("SELECT * FROM ".TB_PREFIX."users WHERE tribe = 2 and id>3");
    $tribe3 = mysql_query("SELECT * FROM ".TB_PREFIX."users WHERE tribe = 3 and id>3");
    $tribes = array(mysql_num_rows($tribe1),mysql_num_rows($tribe2),mysql_num_rows($tribe3));
    $users = mysql_num_rows(mysql_query("SELECT * FROM ".TB_PREFIX."users WHERE id>3"));
    $actives = mysql_num_rows(mysql_query("SELECT * FROM ".TB_PREFIX."active"));
    $onlines = mysql_num_rows(mysql_query("SELECT * FROM ".TB_PREFIX."users WHERE ".time()." - timestamp < 300"));
    $banned = mysql_num_rows(mysql_query("SELECT * FROM ".TB_PREFIX."users WHERE access = 0"));
    $villages = mysql_num_rows(mysql_query("SELECT * FROM ".TB_PREFIX."vdata"));
    $alliances = mysql_num_rows(mysql_query("SELECT * FROM ".TB_PREFIX."alidata"));
    $adventures = mysql_num_rows(mysql_query("SELECT * FROM ".TB_PREFIX."adventure"));
    $auctions = mysql_num_rows(mysql_query("SELECT * FROM ".TB_PREFIX."auction WHERE finish = 0"));
    $notices = mysql_num_rows(mysql_query("SELECT * FROM ".TB_PREFIX."ndata"));
    $movements = mysql_num_rows(mysql_query("SELECT * FROM ".TB_PREFIX."movement WHERE proc = 0"));
    $allvillages = mysql_num_rows(mysql_query("SELECT * FROM ".TB_PREFIX."wdata WHERE oasistype = 0"));
    $alloasis = mysql_num_rows(mysql_query("SELECT * FROM ".TB_PREFIX."wdata WHERE fieldtype = 0"));
    $occoasis = mysql_num_rows(mysql_query("SELECT * FROM ".TB_PREFIX."wdata WHERE fieldtype = 0 and occupied!=0"));
    ?><br />
    <table id="server_info" width="170" border="1" bgcolor="#E5E5E5" cellpadding="2">
            <tbody>
                <tr>
                    <td align="center" colspan="2"><b>اطلاعات سرور</b><br /><br /></td>
                </tr>
                <tr>
                    <td>بازیکنان عضو شده:</td>
                    <td><?php echo $users; ?></td>
                </tr>
                <tr>
                    <td>بازیکنان فعال:</td>
                    <td><?php echo $actives; ?></td>
                </tr>
                <tr>
                    <td>بازیکنان آنلاین:</td>
                    <td><?php echo $onlines; ?></td>
                </tr>
                <tr>
                    <td>بازداشت شده ها:</td>
                    <td><?php echo $banned; ?></td>
                </tr>
                <tr>
                    <td>اتحاد ها:</td>
                    <td><?php echo $alliances; ?></td>
                </tr>
                <tr>
                    <td>ماجراجویی ها:</td>
                    <td><?php echo $adventures; ?></td>
                </tr>
                <tr>
                    <td>حراجی ها:</td>
                    <td><?php echo $auctions; ?></td>
                </tr>
                <tr>
                    <td>گزارش ها:</td>
                    <td><?php echo $notices; ?></td>
                </tr>
                <tr>
                    <td>حرکت ها:</td>
                    <td><?php echo $movements; ?></td>
                </tr>
            </tbody>
    </table>
    <br /><br />
    <div style="margin-right:200px;margin-top:-220px;">
    <table id="server_info" width="170" border="1" bgcolor="#E5E5E5" cellpadding="2">
        <thead align="center">
            <tr>
                <td colspan="3" align="center"><b>اطلاعات بازیکنان</b><br><br></td>
            </tr>
            <tr>
                <td><b>نژاد</b></td>
                <td><b>تعداد</b></td>
                <td><b>درصد</b></td>
            </tr>
        </thead>
        <tbody>
            
            <tr>
                <td>رومی ها:</td>
                <td><?php echo $tribes[0]; ?></td>
                <td><?php $percents = 100*($tribes[0] / $users); echo round($percents,1); ?>%</td>
            </tr>
            <tr>
                <td>توتن ها:</td>
                <td><?php echo $tribes[1]; ?></td>
                <td><?php $percents = 100*($tribes[1] / $users); echo round($percents,1); ?>%</td>
            </tr>
            <tr>
                <td width="60">گول ها:</td>
                <td width="20"><?php echo $tribes[2]; ?></td>
                <td><?php $percents = 100*($tribes[2] / $users); echo round($percents,1); ?>%</td>
            </tr>
        </tbody>
    </table>
    </div>
    
    <div style="margin-right:400px;margin-top:-104px;">
    <table id="server_info" width="170" border="1" bgcolor="#E5E5E5" cellpadding="2">
        <thead align="center">
            <tr>
                <td colspan="2" align="center"><b>اطلاعات نقشه</b><br><br></td>
            </tr>
        </thead>
        <tbody>
            
            <tr>
                <td>کل دهکده ها:</td>
                <td><?php echo $allvillages; ?></td>
            </tr>
            <tr>
                <td>دهکده های تسخیر شده:</td>
                <td><?php echo $villages; ?></td>
            </tr>
            <tr>
                <td>کل آبادی ها:</td>
                <td><?php echo $alloasis; ?></td>
            </tr>
            <tr>
                <td>آبادی های تسخیر شده:</td>
                <td><?php echo $occoasis; ?></td>
            </tr>
            <tr>
                <td>حداکثر گنجایش نقشه:</td>
                <td><?php echo WORLD_MAX."x".WORLD_MAX; ?></td>
            </tr>
        </tbody>
    </table>
    </div>
</div>