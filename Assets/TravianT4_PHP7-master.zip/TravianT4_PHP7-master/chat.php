<script type="text/javascript"> var av_chat_lang = 'it'; </script>
<script type="text/javascript" src="http://tl.altervista.org/js/chat.js"></script>