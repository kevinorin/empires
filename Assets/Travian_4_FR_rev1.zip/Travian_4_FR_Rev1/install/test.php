﻿<?php
	$time = time();
	rename("../install/","../installed_".$time);
?>