<?php
  
?>
 <h3 class="pop popgreen bold">Rules.</h3> 
 <br>
 <p>Not finished.</p> 