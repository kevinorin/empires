<?php
#################################################################################
##                                                                             ##
##              -= YOU MUST NOT REMOVE OR CHANGE THIS NOTICE =-                ##
##                                                                             ##
## --------------------------------------------------------------------------- ##
##                                                                             ##
##  Project:       Travian                                                    ##
##  Version:       2011.11.01                                                  ##
##  Filename:      serverLogin.php                                             ##
##  Edited by:     k1d4r3                                                     ##
##  License:       Creative Commons BY-NC-SA 3.0                               ##
##  Copyright:     Travian (c) 2011 - All rights reserved                     ##
##  Source code:   https://sourceforge.net/projects/travian4clonefr/                      ##
##                                                                             ##
#################################################################################
error_reporting(E_ALL);
if (!file_exists('GameEngine/config.php')) {
header("Location: install/");
}
       include ("GameEngine/Database.php");
       include ("GameEngine/Lang/".$result['lang'].".php");
	   $users = mysql_num_rows(mysql_query("SELECT * FROM " . TB_PREFIX . "users"));
	   $online = mysql_num_rows(mysql_query("SELECT * FROM " . TB_PREFIX . "users WHERE " . time() . "-timestamp < (60*5) AND tribe!=5 AND tribe!=0"));
?>
<h3 class="pop popgreen bold">S'il vous pla�t choisir un serveur.</h3>
<div class="server serverA serverbig servernormal serverbignormal ">
<a class="link" onclick="" href="login.php" title="Log in to Server 1.">
<span class="name">Serveur 1</span>
<span class="player" title="Players in total: <?php echo $users-4; ?>"><?php echo $users-4; ?></span>
<span class="online" title="Players online: <?php echo $online; ?>"><?php echo $online; ?></span>
<span class="start">Le serveur a commenc� <?php echo round((time()-COMMENCE)/86400);?> jours.</span>
<span class="mark"></span>
<img class="hover" src="img/x.gif">
</a>
</div>