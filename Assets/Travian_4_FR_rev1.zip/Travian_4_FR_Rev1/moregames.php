<h3 class="pop popgreen bold">Plus de jeux</h3>
<div class="games">
    <div class="games-img" id="travian"></div>
    <div class="games-details">
        <h3 class="mg bold">TRAVIAN</h3>
        <p>Travian est l'ensemble Browsergame prim� dans un monde persistant ancienne. Commencez le jeu en tant que leader d'un petit village; � partir de l�, vous pouvez grandir et se d�velopper, mener des guerres ou effectuer des transactions pacifiques avec ses voisins. Frayez-vous un chemin vers le sommet tr�s � l'aide de vos alli�s et les conf�d�rations, et de devenir l'empire le plus puissant dans le jeu.</p>
        <div class="btn-green">
            <div class="btn-green-l"></div>
            <div class="btn-green-c">
                <a target="blank" class="npage" href="http://sourceforge.net/projects/travianclonefr/">T�l�charger le clone</a>
            </div>
            <div class="btn-green-r"></div>
        </div>
    </div>
</div>
<div class="games-divider">
</div>