<?php
#################################################################################
##              -= YOU MAY NOT REMOVE OR CHANGE THIS NOTICE =-                 ##
## --------------------------------------------------------------------------- ##
##  Filename       WorldWonderName.php                                         ##
##  Developed by:  k1d4r3                                                       ##
##  License:       Travian Project                                            ##
##  Copyright:     Travian (c) 2010-2011. All rights reserved.                ##
##                                                                             ##
#################################################################################

include("../Village.php");
$database->submitWWname($_POST['vref'],$_POST['wwname']);
 header("Location: ../../build.php?id=99&n");
 
 ?>