<?php

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                             Travian                                             //
//            Only for advanced users, do not edit if you dont know what are you doing!             //
//                                Made by: K1d4r3                                 //
//                              - Travian = Travian Clone Project -                                //
//                                 DO NOT REMOVE COPYRIGHT NOTICE!                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                    //                         //
									//         ENGLISH         //
			                        //      Author: k1d4r3      //
									/////////////////////////////

//MAIN MENU
define("TRIBE1","Romains"); 
define("TRIBE2","Teutons");
define("TRIBE3","Gaulois"); 
define("TRIBE4","Nature"); 
define("TRIBE5","Natars");
define("TRIBE6","Monstres");
 
define("HOME","Page d'accueil"); 
define("INSTRUCT","Instructions");
define("ADMIN_PANEL","Panel admin");
define("MASS_MESSAGE","Masse Message");
define("LOGOUT","D�connexion");
define("PROFILE","Profil");
define("SUPPORT","Support");
define("UPDATE_T_10","MAJ Top 10");
define("SYSTEM_MESSAGE","Syst�me message");
define("TRAVIAN_PLUS","Travian <b><span class=\"plus_g\">P</span><span class=\"plus_o\">l</span><span class=\"plus_g\">u</span><span class=\"plus_o\">s</span></span></span></b>");
define("CONTACT","Contactez-nous!");

define("HEADER_MESSAGES","Messages");
define("HEADER_PLUS","Plus");
define("HEADER_ADMIN","Admin");
define("HEADER_PLUSMENU","Menu Plus");
define("HEADER_NOTICES","Rapports");
define("HEADER_STATS","Statistiques");
define("HEADER_MAP","Map");
define("HEADER_DORF2","Centre du village");
define("HEADER_DORF1","Ressource");
define("HEADER_GOLD","Or");
define("HEADER_SILVER","Argent");
define("HEADER_NIGHT","Nuit");
define("HEADER_DAY","Jour");
define("HEADER_NOTICES_NEW","Nouveau rapport");


define("SIDEINFO_ADVENTURES","Aventure");
define("SIDEINFO_AUCTIONS","Ench�res");
define("SIDEINFO_PROFILE","Profil");
define("SIDEINFO_ALLIANCE","Alliance");
define("SIDEINFO_CHANGE_TITLE","Double-cliquez pour renommer le village");
define("SIDEINFO_CHANGEVIL_TITLE","Changement de nom du village");
define("SIDEINFO_CHANGEVIL_LABEL","Nouveau nom du village");
define("SIDEINFO_CHANGEVIL_BTN","Annuler");

define("LOGOUT_TITLE","D�connexion compl�te!");
define("LOGOUT_H4","Merci de votre visite");
define("LOGOUT_DESC","Si plusieurs personnes utilisent cet ordinateur, vous devez effacer le cookie avec votre nom d'utilisateur et mot de passe pour des raisons de s�curit�");
define("LOGOUT_LINK","Effacer les cookies");

define("LOGIN_WELCOME","Bienvenue sur le serveur");
define("LOGIN_USERNAME","Nom d'utilisateur");
define("LOGIN_PASSWORD","Mot de passe");
define("LOGIN_LOWRES_DESC","Basse r�solution");
define("LOGIN_LOWRES_OPTION","Modifier pour les joueurs");
define("LOGIN_LOWRES_NOTICE","(Remarque: Toutes les options sur cette carte ne peut pas �tre modifier)");
define("LOGIN_PW_FORGOTTEN","Mot de passe oubli�");

define("LOGIN_PW_REQUEST","Demande de mot de passe");
define("LOGIN_PW_EMAIL","Email");
define("LOGIN_PW_BTN","Go");

define("REGISTER_USERINFO","S'inscrire");
define("REGISTER_USERNAME","Nom");
define("REGISTER_EMAIL","Email");
define("REGISTER_PASSWORD","Mot de passe");
define("REGISTER_STARTER","Si vous avez r�cemment rencontr� Travian, il est recommand� de choisir une race gauloise.");
define("REGISTER_SELECT_TRIBE","S�lectionnez une tribu");
define("REGISTER_LOCATION","Emplacement");
define("REGISTER_NE","Nord-Est");
define("REGISTER_NW","Nord-Ouest");
define("REGISTER_SE","Sud-Est");
define("REGISTER_SW","Sud-Ouest");
define("REGISTER_RANDOM","Al�atoire");
define("REGISTER_MOREINFO","T&C");

//MENU
define("REG","S'inscrire");
define("FORUM","Forum");
define("CHAT","Chat");
define("IMPRINT","Mentions l�gales");
define("MORE_LINKS","Plus de liens");
define("TOUR","Tour de jeu");


//ERRORS
define("USRNM_EMPTY","(Pseudo vide)");
define("USRNM_TAKEN","(Le nom est d�j� en cours d'utilisation.)");
define("USRNM_SHORT","(min. ".USRNM_MIN_LENGTH." chiffres)");
define("USRNM_CHAR","(Caract�res non valides)");
define("PW_EMPTY","(Mot de passe vide)");
define("PW_SHORT","(min. ".PW_MIN_LENGTH." chiffres)");
define("PW_INSECURE","(Mot de passe non s�curis�. S'il vous pla�t choisir un plus s�r.)");
define("EMAIL_EMPTY","(Email vide)");
define("EMAIL_INVALID","(Adresse email invalide)");
define("EMAIL_TAKEN","(L'email est d�j� en cours d'utilisation)");
define("TRIBE_EMPTY","<li>S'il vous pla�t choisir une tribu.</li>");
define("AGREE_ERROR","<li>Vous devez accepter les r�gles du jeu et les conditions g�n�rales de vente afin de vous inscrire.</li>");
define("LOGIN_USR_EMPTY","Entrez le nom.");
define("LOGIN_PASS_EMPTY","Entrez le mot de passe.");
define("EMAIL_ERROR","Email ne correspond pas.");
define("PASS_MISMATCH","Les mots de passe ne correspondent pas.");
define("ALLI_OWNER","S'il vous pla�t nommer un propri�taire de l'alliance avant de la supprimer");
define("SIT_ERROR","Gardien d�j� utilis�");
define("USR_NT_FOUND","Le nom n'existe pas.");
define("LOGIN_PW_ERROR","Le mot de passe est erron�.");
define("WEL_TOPIC","Conseils utiles et informations");
define("ATAG_EMPTY","Tag vide");
define("ANAME_EMPTY","Nom vide");
define("ATAG_EXIST","Tag pris");
define("ANAME_EXIST","Nom pris");

//COPYRIGHT
define("TRAVIAN_COPYRIGHT","Travian Clone FR");

//BUILD.TPL
define("CUR_PROD","Production actuelle");
define("NEXT_PROD","Production au niveau ");

//BUILDINGS
define("B1","B�cheron");
define("B1_DESC","Le b�cheron abat des arbres. Plus vous �tendez les camp de b�cheron plus vous avez de bois.");
define("B2","Carri�re d'argile");
define("B2_DESC","L'argile est produite ici. En augmentant son niveau, vous augmenter sa production d'argile.");
define("B3","Mine de fer");
define("B3_DESC","Ici les mineurs produisent du fer, une ressource pr�cieuse. En augmentant la mine vous augmenter sa production de fer.");
define("B4","Terres cultiv�es");
define("B4_DESC","Votre population d�pend de la nourriture produite ici. En augmentant la ferme vous augmenter sa production agricole.");

//DORF1
define("LUMBER","Bois");
define("CLAY","Argile");
define("IRON","Fer");
define("CROP","C�r�ale");
define("LEVEL","Niveau");
define("CROP_COM",CROP." consommation");
define("PER_HR","par heure");
define("PROD_HEADER","Production");
define("MULTI_V_HEADER","Villages");
define("ANNOUNCEMENT","Annonce");
define("GO2MY_VILLAGE","Acc�der � mon village");
define("VILLAGE_CENTER","Centre du village");
define("FINISH_GOLD","Terminer toutes les commandes de construction et de la recherche dans ce village imm�diatement pour 2 m�dailles d'or?");
define("WAITING_LOOP","(attente en boucle)");
define("HRS","(heures.)");
define("DONE_AT","fait �");
define("CANCEL","quittez");
define("LOYALTY","Loyaut�:"); 
define("CALCULATED_IN","Calcul� en");
define("SEVER_TIME","Heure du serveur:");  

//QUEST
define("Q_CONTINUE","Continue with the next task.");
define("Q_REWARD","Your reward:");
define("Q0","Welcome to ");
define("Q0_DESC","As I see you have been made chieftain of this little village. I will be your counselor for the first few days and never leave your (right hand) side.");
define("Q0_OPT1","To the first task.");
define("Q0_OPT2","Look around on your own.");
define("Q0_OPT3","Play no tasks.");

define("Q1","Task 1: Woodcutter");
define("Q1_DESC","There are four green forests around your village. Construct a woodcutter on one of them. Lumber is an important resource for our new settlement.");
define("Q1_ORDER","Order:<\/p>Construct a woodcutter.");
define("Q1_RESP","Yes, that way you gain more lumber.I helped a bit and completed the order instantly.");
define("Q1_REWARD","Woodcutter instantly completed.");

define("Q2","Task 2: Crop");
define("Q2_DESC","Now your subjects are hungry from working all day. Extend a cropland to improve your subjects' supply. Come back here once the building is complete.");
define("Q2_ORDER","Order:<\/p>Extend one cropland.");
define("Q2_RESP","Very good. Now your subjects have enough to eat again...");

define("Q3","Task 3: Your Village's Name");
define("Q3_DESC","Creative as you are you can grant your village the ultimate name.\r\n<br \/><br \/>\r\nClick on 'profile' in the left hand menu and then select 'change profile'...");
define("Q3_ORDER","Order:<\/p>Change your village's name to something nice.");
define("Q3_RESP","Wow, a great name for their village. It could have been the name of my village!...");

define("Q4","Task 4: Other Players");
define("Q4_DESC","In ". SERVER_NAME ." you play along with billions of other players. Click 'statistics' in the top menu to look up your rank and enter it here.");
define("Q4_ORDER","Order:<\/p>Look for your rank in the statistics and enter it here.");
define("Q4_BUTN","complete task");
define("Q4_RESP","Exactly! That's your rank.");

define("Q5","Task 5: Two Building Orders");
define("Q5_DESC","Build an iron mine and a clay pit. Of iron and clay one can never have enough.");
define("Q5_ORDER","Order:<\/p><ul><li>Extend one iron mine.<\/li><li>Extend one clay pit.<\/li><\/ul>");
define("Q5_RESP","As you noticed, building orders take rather long. The world of ". SERVER_NAME ." will continue to spin even if you are offline. Even in a few months there will be many new things for you to discover.\r\n<br \/><br \/>\r\nThe best thing to do is occasionally checking your village and giving you subjects new tasks to do.");

define("Q6","Message From The Taskmaster");
define("Q6_DESC","You are to be informed that a nice reward is waiting for you at the taskmaster.<br /><br />Hint: The message has been generated automatically. An answer is not necessary.");

define("Q5","Task 5: Two Building Orders");
define("Q5_DESC","Build an iron mine and a clay pit. Of iron and clay one can never have enough.");
define("Q5_ORDER","Order:<\/p><ul><li>Extend one iron mine.<\/li><li>Extend one clay pit.<\/li><\/ul>");
define("Q5_RESP","As you noticed, building orders take rather long. The world of ". SERVER_NAME ." will continue to spin even if you are offline. Even in a few months there will be many new things for you to discover.\r\n<br \/><br \/>\r\nThe best thing to do is occasionally checking your village and giving you subjects new tasks to do.");

//======================================================//
//================ UNITS - DO NOT EDIT! ================//
//======================================================//
// HEROE UNIT
define("U0","H�ro");

//ROMAN UNITS
define("U1","L�gionnaire");
define("U2","Pr�torien");
define("U3","Imperian");
define("U4","Equites Legati");
define("U5","Equites Imperatoris");
define("U6","Equites Caesaris");
define("U7","B�lier");
define("U8","Catapulte de feu");
define("U9","S�nateur");
define("U10","Colon");

//TEUTON UNITS
define("U11","Combattant au gourdin");
define("U12","Lancier");
define("U13","Combattant � la hache");
define("U14","Eclaireur");
define("U15","Paladin");
define("U16","Chevalier teutonique");
define("U17","B�lier");
define("U18","Catapulte");
define("U19","Chef");
define("U20","Colon");

//GAUL UNITS
define("U21","Phalange");
define("U22","Ex�cuteur");
define("U23","Eclaireur");
define("U24","Eclair de Toutatis");
define("U25","Cavalier druide");
define("U26","Haeduan");
define("U27","B�lier");
define("U28","Tr�buchet");
define("U29","Chef de clan");
define("U30","Colon");

//NATURE UNITS
define("U31","Rat");
define("U32","Araign&eacute;e");
define("U33","Serpent");
define("U34","Chauve-souris");
define("U35","Sanglier");
define("U36","Loup");
define("U37","Ours");
define("U38","Crocodile");
define("U39","Tigre");
define("U40","Elephant");

//NATARS UNITS
define("U41","Pikeman");
define("U42","Guerrier �pineux");
define("U43","Mousquetaire");
define("U44","Oiseaux de proie");
define("U45","Axerider");
define("U46","Natarian Knight");
define("U47","War Elephant");
define("U48","Ballista");
define("U49","Natarian Emperor");
define("U50","Natarian Colon");

//MONSTER UNITS
define("U51","Fantassin");
define("U52","Chasseur");
define("U53","Guerrier");
define("U54","Fant�me");
define("U55","Destrier");
define("U56","Destrier de guerre");
define("U57","B�lier");
define("U58","Catapulte");
define("U59","Chef");
define("U60","Colon");

//INDEX.php
define("LOGIN","Connexion");
define("PLAYERS","Joueurs");
define("ONLINE","En Ligne");
define("TUTORIAL","Tutorial");
define("PLAYER_STATISTICS","Statistique joueurs");
define("TOTAL_PLAYERS","".PLAYERS." aux total");
define("ACTIVE_PLAYERS","Joueurs actifs");
define("ONLINE_PLAYERS","".PLAYERS." en ligne");
define("MP_STRATEGY_GAME","".SERVER_NAME." - le jeu de strat&eacute;gie multijoueur");
define("WHAT_IS","".SERVER_NAME." est l'un des jeux sur navigateur le plus populaire dans le monde. Comme un joueur de ".SERVER_NAME.", vous allez construire votre propre empire, de recruter une arm&eacute;e puissante, et se battre avec vos alli&eacute;s pour l'h&eacute;g&eacute;monie mondiale match.");
define("REGISTER_FOR_FREE","Inscrivez-vous ici gratuitement!");
define("LATEST_GAME_WORLD","Dernier jeu du monde");
define("LATEST_GAME_WORLD2","Inscrivez-vous sur le jeu et profiter des avantages d'un des premier joueurs.");
define("PLAY_NOW","Jouez ".SERVER_NAME." aujourd'hui");
define("LEARN_MORE","En savoir plus <br/>&agrave; propos ".SERVER_NAME."!");
define("LEARN_MORE2","Maintenant, avec un syst&egrave;me serveur <br>r&eacute;volutionn&eacute; compl&egrave;tement nouveau<br> graphiques !");
define("COMUNITY","Communaut&eacute;");
define("BECOME_COMUNITY","Devenez membre de notre communaut&eacute; d&egrave;s maintenant!");
define("BECOME_COMUNITY2","Devenez une partie de l'un des<br> plus grand jeu<br>communaut&eacute;s dans le<br>monde.");
define("NEWS","News");
define("SCREENSHOTS","Captures d'&eacute;cran");
define("LEARN1","Am&eacute;liorez votre champs et les mines pour augmenter votre production de ressources. Vous aurez besoin de ressources pour construire des b&acirc;timents et former des soldats.");
define("LEARN2","Construire et d&eacute;velopper les b&acirc;timents de votre village. Les b&acirc;timents am&eacute;liore votre infrastructure globale, augmenter votre production de ressources vous permet de faire des recherche, former et am&eacute;liorer vos troupes.");
define("LEARN3","Visualiser et interagir avec votre environnement. Vous pouvez faire de nouveaux amis ou de nouveaux ennemis, faire usage de l'oasis &agrave; proximit&eacute; et d'observer comme votre empire se d&eacute;veloppe et devient plus fort.");
define("LEARN4","Suivez vos progr&egrave;s et succ&egrave;s, vous comparer aux autres joueurs. Regardez le Top 10 des classements et se battre pour gagner une m&eacute;daille hebdomadaire.");
define("LEARN5","Recevoir des rapports d&eacute;taill&eacute;s sur vos aventures, des m&eacute;tiers et des batailles. Ne pas oublier de v&eacute;rifier les rapports flambant neuf sur les &eacute;v&eacute;nements qui ont lieu dans votre entourage.");
define("LEARN6","Echange d'information et de la diplomatie avec d'autres joueurs. Toujours se rappeler que la communication est la cl&eacute; pour gagner de nouveaux amis et de r&eacute;soudre de vieux conflits.");
define("LOGIN_TO","Connectez-vous &agrave; ". SERVER_NAME);
define("REGIN_TO","Inscrivez-vous sur ". SERVER_NAME);
define("P_ONLINE","Joueurs en ligne: ");
define("P_TOTAL","Joueurs au total: ");
define("CHOOSE","S'il vous pla&icirc;t choisir un serveur.");
define("STARTED"," Le serveur a commenc&eacute; ". round((time()-COMMENCE)/86400) ." jours auparavant.");

//ANMELDEN.php
define("NICKNAME","Nom du joueur");
define("EMAIL","Email");
define("PASSWORD","Mot de passe");
define("ROMANS","Romains");
define("TEUTONS","Teutons");
define("GAULS","Gaulois");
define("NW","Nord-Ouest");
define("NE","Nord-Est");
define("SW","Sud-Ouest");
define("SE","Sud-Est");
define("RANDOM","Al&eacute;atoire");
define("ACCEPT_RULES"," J'accepte les r&egrave;gles du jeu et conditions g&eacute;n&eacute;rales.");
define("ONE_PER_SERVER","Chaque joueur ne peut poss&eacute;der qu'un seule compte par serveur.");
define("BEFORE_REGISTER","Avant de vous inscrire un compte, vous devriez lire les <a href='../anleitung.php' target='_blank'>instructions</a> du Tyran pour voir les avantages et inconv&eacute;nients des trois tribus.");
define("BUILDING_UPGRADING","b&acirc;timent:");
define("HOURS","heures");


//ATTACKS ETC.
define("TROOP_MOVEMENTS","Mouvements de troupes:");
define("ARRIVING_REINF_TROOPS","Arriv&eacute; troupes de renfort");
define("ARRIVING_REINF_TROOPS_SHORT","Renfort.");
define("OWN_ATTACKING_TROOPS","Propri&eacute;taire troupes assaillantes");
define("ATTACK","Attaque");
define("OWN_REINFORCING_TROOPS","Propri&eacute;taire troupes de renfort");
define("TROOPS_DORF","Troupes:");


//LOGIN.php
define("COOKIES","Vous devez activer les cookies pour &ecirc;tre capable de vous connecter si vous partagez cet ordinateur avec d'autres personnes vous devez vous d&eacute;connecter apr&egrave;s chaque session pour votre propre s&eacute;curit&eacute;.");
define("NAME","Nom");
define("PW_FORGOTTEN","Mot de passe oubli&eacute;?");
define("PW_REQUEST","Ensuite, vous pouvez en demander un nouveau qui sera envoy&eacute; &agrave; votre adresse email.");
define("PW_GENERATE","Tous les champs obligatoires");
define("EMAIL_NOT_VERIFIED","L'email n'est pas v&eacute;rifi&eacute;e!");
define("EMAIL_FOLLOW","Suivez ce lien pour activer votre compte.");
define("VERIFY_EMAIL","V&eacute;rifiez email.");
define("LOGIN_SERVER_START","Le serveur commence dans:");


//404.php
define("NOTHING_HERE","Rien ici!");
define("WE_LOOKED","Nous avons regard&eacute; 404 fois d&eacute;j&agrave; mais ne trouve rien");

//TIME RELATED
define("CALCULATED","Calcul&eacute; en");
define("SERVER_TIME","Serveur de temps:");

//MASSMESSAGE.php
define("MASS","Contenu du message");
define("MASS_SUBJECT","Sujet:");
define("MASS_COLOR","Couleur du message:");
define("MASS_REQUIRED","Tous les champs obligatoires");
define("MASS_UNITS","Images (unit&eacute;s):");
define("MASS_SHOWHIDE","Afficher / Masquer");
define("MASS_READ","Lisez ceci: apr&egrave;s l'ajout de smiley, vous devez ajouter &agrave; gauche ou &agrave; droite apr&egrave;s le num&eacute;ro de l'image sera par ailleurs ne fonctionnera pas");
define("MASS_CONFIRM","Confirmation");
define("MASS_REALLY","Voulez-vous vraiment envoyer MassIGM?");
define("MASS_ABORT","Abandon d&egrave;s maintenant");
define("MASS_SENT","Mass IGM a &eacute;t&eacute; envoy&eacute;");

// Menu items

	define("GAME_TOUR","Tour de jeu");
	define("FORUM","Forum");
	define("FORUM_LINK","#");
	define("MORE_GAMES","Plus de jeux");
	define("REGISTER","S'inscrire");
	define("LOGIN","Connexion");
	define("MANUAL","Manual");
	define("TUTORIAL","Tutorial");
	define("SCREENSHOTS","Captures d'�cran");
	define("FAQ","FAQ");
	define("SPIELREGELN","R�gles du jeu");
	define("AGB","Termes");
	define("IMPRINT","Mentions l�gales");
	define("SUPPORT","Support");
	define("LINKS","Liens");
	define("HOME","Accueil");
	define("PROFILE","Profil");
	define("INSTRUCTIONS","Instructions");
	define("ADMIN_PANEL","Panel administrateur");
	define("MULTIHUNTER_PANEL","Panel mod�rateur");
	define("MASS_MESSAGE","Mass Message");
	define("UPDATE_TOP_TEN","MAJ Top 10");
	define("SYSTEM_MESSAGE","Message syst�me");
	define("LOGOUT","D�connexion");
	define("HELP","Aide");
	define("TRAVIAN_PLUS",SERVER_NAME." <b><span class=\"plus_g\">P</span><span class=\"plus_o\">l</span><span class=\"plus_g\">u</span><span class=\"plus_o\">s</span></span></span></b>");

// Index

	define("WELCOME","Bienvenue sur ".SERVER_NAME);
	define("PLAY_NOW","Jouez d�s maintenant, gratuitement!");
	define("WHAT_IS","Qu'est-ce que ".SERVER_NAME);
	define("GAME_DESCRIPTION",SERVER_NAME." est un <b>jeu par navigateur</b> avec un monde ancien avec des milliers d'autres joueurs r�els.</p><p>Il est <strong>gratuit</strong> et n�cessite <strong>aucun t�l�chargement</strong>.");
	define("CLICK_HERE","Cliquez ici pour jouer ".SERVER_NAME);
	define("ABOUT","A propos du jeu");
	define("ABOUT1","Vous commencerez en tant que chef d'un petit village et vous vous lancez dans une qu�te passionnante.");
	define("ABOUT2","Construisez des villages, des guerres, des salaires ou �tablir des routes commerciales avec vos voisins.");
	define("ABOUT3","Jouez avec et contre des milliers d'autres joueurs r�els et conqu�rir le monde de ".SERVER_NAME.".");
	define("NEWS","News");
	define("CHOOSE_WORLD","Choisissez votre monde");
	
// Index Travian 4

	define("","");

	$lang['index2']['description'] = 'Ma�trisez l\'art de la tactique ancienne en tant que romain, gaulois ou teuton!';
	$lang['index2']['shop title'] = SERVER_NAME.' boutique';
	$lang['index2']['shop'] = 'Aller � la boutique';
	$lang['index2']['shop link'] = 'http://sourceforge.net/projects/travianclonefr/';
	$lang['index2']['facebook'] = 'http://www.facebook.com/traviannews';
	$lang['index2']['strategy game'] = SERVER_NAME.' - le jeu de strat�gie multijoueur';
	$lang['index2']['what is'] = SERVER_NAME.' est l\'un des jeux par navigateur les plus populaires dans le monde. En tant que joueur de '.SERVER_NAME.', vous allez construire votre propre empire, recruter une arm�e puissante, et se battre avec vos alli�s pour l\'h�g�monie mondiale.';
	$lang['index2']['register free'] = 'Inscrivez-vous ici gratuitement!';
	$lang['index2']['title1'] = 'Le monde le plus r�cent du jeu';
	$lang['index2']['desc1'] = 'Inscrivez-vous sur le dernier monde du jeu <br/>et de profiter<br/> des avantages <br/> �tant l\'un des premiers joueurs.';
	$lang['index2']['text1'] = 'Jouer � '.SERVER_NAME.' maintenant';
	$lang['index2']['link1'] = '#serverRegister';
	$lang['index2']['title2'] = 'La nouvelle '.SERVER_NAME;
	$lang['index2']['desc2'] = 'Maintenant, avec un syst�me de h�ros r�volutionnaire <br/> et <br/> un nouveaux graphismes compl�tement in�dit <br/> et une carte interactive <br/>!';
	$lang['index2']['text2'] = 'Explorez le nouveau '.SERVER_NAME;
	$lang['index2']['link2'] = '#serverRegister';
	$lang['index2']['title3'] = 'Communaut�';
	$lang['index2']['desc3'] = 'Devenir une partie d\'un <br /> monde toujours plus grand et <br/>communaut�s dans le monde<br/>.';
	$lang['index2']['text3'] = 'Faites partie de notre communaut� aujourd\'hui!';
	$lang['index2']['link3'] = '#';
	$lang['index2']['learn more'] = 'En savoir plus <br/>sur '.SERVER_NAME.'!';
	$lang['index2']['strip1'] = 'Am�liorez vos champs et les mines pour augmenter votre production de ressources. Vous aurez besoin de ressources pour construire des b�timents et des soldats du train.';
	$lang['index2']['strip2'] = 'Construire et d�velopper les b�timents de votre village. B�timents � am�liorer votre infrastructure globale, augmenter votre production de ressources et vous permettra de la recherche, former et am�liorer vos troupes.';
	$lang['index2']['strip3'] = 'Visualiser et d\'interagir avec votre environnement. Vous pouvez faire de nouveaux amis ou de nouveaux ennemis, faire usage des oasis � proximit� et d\'observer comme votre empire grandit et devient plus fort.';
	$lang['index2']['strip4'] = 'Suivez vos progr�s et de succ�s et vous comparer aux autres joueurs. Regardez le Top 10 des classements et se battre pour remporter une m�daille hebdomadaire.';
	$lang['index2']['strip5'] = 'Recevoir des rapports d�taill�s sur vos aventures, des m�tiers et des batailles. Ne pas oublier de v�rifier les rapports de toutes nouvelles sur les �v�nements qui se d�roulent dans votre environnement.';
	$lang['index2']['strip6'] = '�changer des informations et de la diplomatie conduite avec d\'autres joueurs. Rappelez-vous toujours que la communication est la cl� pour gagner de nouveaux amis et de r�soudre d\'anciens conflits.';

// Screenshots Travian 4

	define("SCREENSHOTS_T4_TITLE1","Village centre");
	define("SCREENSHOTS_T4_TITLE2","Village overview");
	define("SCREENSHOTS_T4_TITLE3","The hero");
	define("SCREENSHOTS_T4_TITLE4","Building information");
	define("SCREENSHOTS_T4_TITLE5","Surrounding territories");
	define("SCREENSHOTS_T4_TITLE6","Battle report");
	define("SCREENSHOTS_T4_TITLE7","Medals system");
	define("SCREENSHOTS_T4_TITLE8","Task system");
	define("SCREENSHOTS_T4_DESC1","Your village could like this one day, becoming the starting point for your vast empire.");
	define("SCREENSHOTS_T4_DESC2","Lumber, clay, iron and crop are the vital resources which will fuel the economy of your village and feed your people; they will provide you with the materials necessary for construction and war. With these valuable resources, you can train a powerful conquering army.");
	define("SCREENSHOTS_T4_DESC3","You can send your hero to adventures, where he will have to face great danger and pass difficult challenges. If your hero is successful, he stands a chance of bringing something valuable home.");
	define("SCREENSHOTS_T4_DESC4","For it to become powerful and productive, your village will need a great number of buildings. At the beginning, choose well what you want to construct first, as resources are scarce.");
	define("SCREENSHOTS_T4_DESC5","Explore your surrounding territories in order to get to know your neighbors; you can opt for a path of peace, creating alliances and confederacies, or you can wage war and conquer the surrounding lands. There may be rich oases in your vicinity; conquer them to gain various valuable bonuses, but always be aware of the dangerous wild animals that inhabit them.");
	define("SCREENSHOTS_T4_DESC6","It is wise to train your army early on, so you can defend yourself and attack others. This way, you can raid more resources and build up your empire more quickly.");
	define("SCREENSHOTS_T4_DESC7","At the end of every week, the very best 10 players and alliances will be elected, topping in different categories; as a reward for their prowess they will receive medals, celebrating their achievements.");
	define("SCREENSHOTS_T4_DESC8","To assist you when you first start managing your empire, we have sent the Taskmaster; he will guide you with tips and advice in order to help you build up your village. Just click on the image of the Taskmaster to your left to activate him.");

	$lang['screenshots2']['desc1'] = 'Your village could like this one day, becoming the starting point for your vast empire.';
	$lang['screenshots2']['desc2'] = 'Lumber, clay, iron and crop are the vital resources which will fuel the economy of your village and feed your people; they will provide you with the materials necessary for construction and war. With these valuable resources, you can train a powerful conquering army.';
	$lang['screenshots2']['desc3'] = 'You can send your hero to adventures, where he will have to face great danger and pass difficult challenges. If your hero is successful, he stands a chance of bringing something valuable home.';
	$lang['screenshots2']['desc4'] = 'For it to become powerful and productive, your village will need a great number of buildings. At the beginning, choose well what you want to construct first, as resources are scarce.';
	$lang['screenshots2']['desc5'] = 'Explore your surrounding territories in order to get to know your neighbors; you can opt for a path of peace, creating alliances and confederacies, or you can wage war and conquer the surrounding lands. There may be rich oases in your vicinity; conquer them to gain various valuable bonuses, but always be aware of the dangerous wild animals that inhabit them.';
	$lang['screenshots2']['desc6'] = 'It is wise to train your army early on, so you can defend yourself and attack others. This way, you can raid more resources and build up your empire more quickly.';
	$lang['screenshots2']['desc7'] = 'At the end of every week, the very best 10 players and alliances will be elected, topping in different categories; as a reward for their prowess they will receive medals, celebrating their achievements.';
	$lang['screenshots2']['desc8'] = 'To assist you when you first start managing your empire, we have sent the Taskmaster; he will guide you with tips and advice in order to help you build up your village. Just click on the image of the Taskmaster to your left to activate him.';

// Player statics

	define("TOTAL_PLAYERS","Joueurs total");
	define("PLAYERS_ACTIVE","Joueurs actifs");
	define("PLAYERS_ONLINE","Joueurs en ligne");
	define("PLAYERS","Joueurs");
	define("ACTIVE","Actifs");
	define("ONLINE","En ligne");
	define("PLAYER_STATISTICS","Statistiques des joueurs");

?>
